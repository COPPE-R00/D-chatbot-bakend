import { z } from "zod";

// Chat message schema for frontend/backend communication
export const messageSchema = z.object({
  id: z.string(),
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  timestamp: z.number(),
});

export type Message = z.infer<typeof messageSchema>;

// Chat request schema
export const chatRequestSchema = z.object({
  messages: z.array(messageSchema),
  message: z.string().min(1, "Message cannot be empty"),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;

// Chat response schema
export const chatResponseSchema = z.object({
  message: z.string(),
  timestamp: z.number(),
});

export type ChatResponse = z.infer<typeof chatResponseSchema>;

// Health topic suggestion type
export interface HealthTopic {
  id: string;
  category: string;
  title: string;
  description: string;
  icon: string;
  prompt: string;
}
