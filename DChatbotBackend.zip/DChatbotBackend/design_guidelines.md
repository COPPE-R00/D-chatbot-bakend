# D Chatbot - Community Health Education Assistant Design Guidelines

## Design Approach
**Selected Framework:** Design System Approach with Healthcare UX Principles  
**Primary Reference:** ChatGPT's conversational interface combined with telemedicine app clarity (like One Medical, Zocdoc)  
**Justification:** Health education requires trust, accessibility, and information clarity. A clean, professional chat interface with strong information hierarchy ensures users can digest health information effectively.

## Core Design Elements

### A. Typography System
**Font Families:**
- Primary: Inter (via Google Fonts) - excellent readability for health content
- Monospace: JetBrains Mono - for any code snippets or technical content

**Typography Hierarchy:**
- Main heading (App title): text-2xl font-semibold
- Section headers: text-lg font-medium
- Chat messages: text-base font-normal
- Metadata (timestamps): text-sm
- Button text: text-sm font-medium
- Helper text/disclaimers: text-xs

### B. Layout System
**Spacing Primitives:** Tailwind units of 2, 3, 4, 6, 8, and 12
- Tight spacing: p-2, gap-2 (within components)
- Standard spacing: p-4, gap-4 (component padding)
- Section spacing: p-6, gap-6 (between major elements)
- Page margins: p-8 (outer containers)
- Large gaps: gap-12 (between major sections)

**Responsive Breakpoints:**
- Mobile-first approach
- Tablet: md: (768px)
- Desktop: lg: (1024px)

**Container Strategy:**
- Chat container: max-w-4xl mx-auto (optimal reading width)
- Full viewport height layout with fixed header and input area
- Scrollable message area in between

### C. Component Library

**1. Application Shell**
- Fixed header: h-16 with app branding, health education subtitle
- Main chat area: flex-1 overflow-y-auto
- Fixed input area: sticky bottom with h-20 container
- Sidebar toggle for mobile: hamburger menu for topic suggestions

**2. Chat Message Components**
- User messages: Right-aligned, max-w-2xl, rounded-2xl rounded-br-sm
- AI messages: Left-aligned, max-w-2xl, rounded-2xl rounded-bl-sm
- Message padding: p-4
- Message spacing: gap-4 between consecutive messages
- Avatar indicators: w-8 h-8 rounded-full (user initials/AI icon)
- Timestamp: text-xs below each message with gap-2

**3. Input Area**
- Multi-line textarea with min-h-12 max-h-32
- Auto-resize as user types
- Send button: h-12 w-12 rounded-full (positioned absolute right)
- Input container: p-4 with rounded-2xl border
- Character count indicator when approaching limits

**4. Health Topic Suggestions (Sidebar/Bottom Sheet)**
Desktop: w-64 fixed left sidebar
Mobile: Bottom sheet slide-up overlay
- Quick action buttons: h-10 rounded-lg with gap-2
- Topic categories: Nutrition, Mental Health, Exercise, Preventive Care, Chronic Conditions
- Each suggestion: p-3 rounded-lg hover-lift effect
- Icon + text layout with gap-3

**5. Welcome/Empty State**
- Centered layout with max-w-2xl
- Hero illustration: h-48 w-48 centered (health education themed graphic)
- Welcome heading: text-3xl font-bold with gap-4
- Subtitle explaining chatbot purpose: text-lg with gap-6
- Starter prompts: Grid of 2 columns (md:grid-cols-2) with gap-4
- Each prompt card: p-4 rounded-xl with icon, title, and brief description

**6. Typing Indicator**
- Three animated dots
- Height: h-6
- Positioned with AI message styling
- Subtle pulse animation

**7. Conversation Controls**
- Clear conversation button: Fixed top-right in header
- Download transcript option: Icon button in header
- Scroll to bottom FAB: Fixed bottom-right (appears when scrolled up)

**8. Disclaimers & Trust Elements**
- Medical disclaimer banner: Sticky top below header initially, dismissible
- "AI-generated information" notice: text-xs below AI responses
- Emergency resources link: Always visible in footer/header

**9. Loading States**
- Initial app load: Centered spinner with h-12 w-12
- Message sending: Disabled input with loading indicator
- API response pending: Typing indicator

**10. Error States**
- Connection error banner: Top of chat area, p-4 rounded-lg
- Failed message indicator: Warning icon next to message with retry button
- Rate limit notice: Inline message in chat

### D. Spacing & Layout Specifications

**Chat Message Layout:**
```
Container padding: p-6
Message gap: gap-6
Message internal: p-4
Avatar-to-message gap: gap-3
Timestamp offset: mt-2
```

**Input Area:**
```
Container: p-4
Textarea padding: p-3
Button positioning: right-3 bottom-3
Mobile keyboard safe area: pb-safe
```

**Sidebar/Topic Suggestions:**
```
Container padding: p-6
Topic section gap: gap-6
Topic button gap: gap-2
Category header margin: mb-4
```

### E. Accessibility Implementation

**Keyboard Navigation:**
- Tab order: Header → Topic suggestions → Chat messages → Input area
- Enter to send, Shift+Enter for new line
- Escape to close modals/sidesheets

**Screen Reader Support:**
- ARIA labels on all interactive elements
- Message role="log" for chat container
- Live region announcements for new messages
- Alt text for all icons and images

**Focus States:**
- Visible focus rings: ring-2 ring-offset-2
- High contrast focus indicators
- Skip to main content link

**Text Contrast:**
- All text meets WCAG AA standards minimum
- Important health information meets AAA standards

### F. Responsive Behavior

**Mobile (< 768px):**
- Single column layout
- Full-width messages with max-w-[85%]
- Bottom sheet for topic suggestions
- Collapsible header on scroll
- Input area fixed to keyboard

**Tablet (768px - 1024px):**
- Wider messages max-w-xl
- Optional sidebar toggle
- Comfortable spacing: p-6

**Desktop (> 1024px):**
- Persistent left sidebar for topics: w-64
- Centered chat: max-w-4xl
- Generous spacing: p-8
- Hover states fully implemented

## Images

**Hero/Welcome State Illustration:**
- Placement: Center of empty state, above welcome text
- Description: Friendly, inclusive illustration showing diverse people engaged in health education activities (reading, exercising, consulting). Warm, approachable style with clean lines. Should convey trust and accessibility.
- Size: h-48 w-48 on mobile, h-64 w-64 on desktop
- Style: Modern flat illustration with simple shapes

**Topic Suggestion Icons:**
- Small icons (w-6 h-6) next to each health topic
- Use Heroicons library for consistency
- Icons: Heart (general health), BeakerIcon (nutrition), BrainIcon (mental health), BoltIcon (exercise), ShieldCheckIcon (preventive care)

**No large hero image** - This is a chat application where the interface should be immediately functional upon load. Focus is on conversation, not marketing.

## Animation Guidelines

**Minimal, Purposeful Motion:**
- Message appearance: Subtle fade-in (200ms)
- Typing indicator: Gentle pulse
- Topic suggestion hover: Slight lift (translate-y-1)
- Sidebar transitions: Smooth slide (300ms)
- NO scroll-triggered animations
- NO background animations
- NO distracting motion effects