import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertCircle, ArrowDown, Trash2, Menu } from "lucide-react";
import { ChatMessage } from "@/components/chat-message";
import { TypingIndicator } from "@/components/typing-indicator";
import { ChatInput } from "@/components/chat-input";
import { WelcomeScreen } from "@/components/welcome-screen";
import { HealthTopicsSidebar } from "@/components/health-topics-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { type Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isAtBottom, setIsAtBottom] = useState(true);
  const [showSidebar, setShowSidebar] = useState(true);
  const [showDisclaimer, setShowDisclaimer] = useState(true);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const currentAssistantIdRef = useRef<string | null>(null);
  const { toast } = useToast();

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const userMessage: Message = {
        id: crypto.randomUUID(),
        role: "user",
        content: message,
        timestamp: Date.now(),
      };
      
      setMessages((prev) => [...prev, userMessage]);

      // Create assistant message that will be updated with streaming content
      const assistantId = crypto.randomUUID();
      currentAssistantIdRef.current = assistantId;
      
      const assistantMessage: Message = {
        id: assistantId,
        role: "assistant",
        content: "",
        timestamp: Date.now(),
      };
      
      setMessages((prev) => [...prev, assistantMessage]);

      // Stream the response
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: messages,
          message: message,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: "Failed to send message" }));
        throw new Error(errorData.error || "Failed to send message");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error("No response stream available");
      }

      let fullContent = "";
      let buffer = "";
      let hasError = false;
      let errorMessage = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Decode with stream: true to handle multi-byte characters across chunks
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        
        // Keep the last incomplete line in the buffer
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              
              if (data.error) {
                hasError = true;
                errorMessage = data.error;
                break;
              }
              
              if (data.content) {
                fullContent += data.content;
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantId
                      ? { ...msg, content: fullContent }
                      : msg
                  )
                );
              }
              
              if (data.done) {
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantId
                      ? { ...msg, timestamp: data.timestamp }
                      : msg
                  )
                );
              }
            } catch (parseError) {
              console.error("Failed to parse SSE data:", line, parseError);
            }
          }
        }
        
        if (hasError) break;
      }
      
      // Flush any remaining multi-byte characters
      buffer += decoder.decode();
      
      // Process any remaining data in the buffer
      if (buffer.startsWith("data: ")) {
        try {
          const data = JSON.parse(buffer.slice(6));
          
          if (data.error) {
            hasError = true;
            errorMessage = data.error;
          } else if (data.content) {
            fullContent += data.content;
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === assistantId
                  ? { ...msg, content: fullContent }
                  : msg
              )
            );
          } else if (data.done) {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === assistantId
                  ? { ...msg, timestamp: data.timestamp }
                  : msg
              )
            );
          }
        } catch (parseError) {
          console.error("Failed to parse final SSE data:", buffer, parseError);
        }
      }
      
      // If an error occurred during streaming, throw it
      if (hasError) {
        throw new Error(errorMessage || "An error occurred during streaming");
      }

      // Clear the current assistant ID on success
      currentAssistantIdRef.current = null;
      return { success: true };
    },
    onSuccess: () => {
      scrollToBottom();
    },
    onError: (error: Error) => {
      // Remove the failed assistant message using the tracked ID
      if (currentAssistantIdRef.current) {
        setMessages((prev) => prev.filter((msg) => msg.id !== currentAssistantIdRef.current));
        currentAssistantIdRef.current = null;
      }
      
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
      });
    },
  });

  const handleSendMessage = (message: string) => {
    chatMutation.mutate(message);
  };

  const handleTopicSelect = (prompt: string) => {
    handleSendMessage(prompt);
  };

  const handleClearConversation = () => {
    setMessages([]);
    toast({
      title: "Conversation cleared",
      description: "Your chat history has been reset.",
    });
  };

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]");
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    const isBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 100;
    setIsAtBottom(isBottom);
  };

  useEffect(() => {
    if (chatMutation.isPending || messages.length > 0) {
      scrollToBottom();
    }
  }, [messages.length, chatMutation.isPending]);

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {/* Sidebar - Desktop */}
      <div className={`hidden lg:block ${showSidebar ? "w-64" : "w-0"} transition-all duration-300`}>
        {showSidebar && <HealthTopicsSidebar onTopicSelect={handleTopicSelect} />}
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b bg-background flex items-center justify-between px-4 flex-shrink-0">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setShowSidebar(!showSidebar)}
              data-testid="button-menu-toggle"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden lg:flex"
              onClick={() => setShowSidebar(!showSidebar)}
              data-testid="button-sidebar-toggle"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-foreground">D Chatbot</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Community Health Education Assistant</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClearConversation}
                data-testid="button-clear-chat"
                aria-label="Clear conversation"
              >
                <Trash2 className="w-5 h-5" />
              </Button>
            )}
            <ThemeToggle />
          </div>
        </header>

        {/* Disclaimer Banner */}
        {showDisclaimer && messages.length > 0 && (
          <Alert className="m-4 mb-0">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between gap-4">
              <span className="text-sm">
                This AI provides educational information only. Always consult healthcare professionals for medical advice.
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDisclaimer(false)}
                data-testid="button-dismiss-disclaimer"
              >
                Dismiss
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Messages Area */}
        <ScrollArea
          ref={scrollAreaRef}
          className="flex-1"
          onScrollCapture={handleScroll}
        >
          {messages.length === 0 ? (
            <WelcomeScreen onTopicSelect={handleTopicSelect} />
          ) : (
            <div className="max-w-4xl mx-auto p-6 space-y-6" role="log" aria-live="polite">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              {chatMutation.isPending && <TypingIndicator />}
            </div>
          )}
        </ScrollArea>

        {/* Scroll to Bottom Button */}
        {!isAtBottom && messages.length > 0 && (
          <Button
            size="icon"
            className="fixed bottom-24 right-6 rounded-full shadow-lg"
            onClick={scrollToBottom}
            data-testid="button-scroll-bottom"
            aria-label="Scroll to bottom"
          >
            <ArrowDown className="w-5 h-5" />
          </Button>
        )}

        {/* Input Area */}
        <ChatInput
          onSend={handleSendMessage}
          disabled={chatMutation.isPending}
          placeholder={messages.length === 0 ? "Ask your first health question..." : "Ask a follow-up question..."}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      {showSidebar && (
        <div className="lg:hidden fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" onClick={() => setShowSidebar(false)}>
          <div className="fixed left-0 top-0 bottom-0 w-64 bg-sidebar border-r" onClick={(e) => e.stopPropagation()}>
            <HealthTopicsSidebar onTopicSelect={(prompt) => {
              handleTopicSelect(prompt);
              setShowSidebar(false);
            }} />
          </div>
        </div>
      )}
    </div>
  );
}
