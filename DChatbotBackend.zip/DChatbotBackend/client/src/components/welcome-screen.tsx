import welcomeImage from "@assets/generated_images/Health_education_welcome_illustration_2bb4ad2a.png";
import { Card } from "@/components/ui/card";
import { Heart, Brain, Activity, Shield, Apple } from "lucide-react";
import { type HealthTopic } from "@shared/schema";

interface WelcomeScreenProps {
  onTopicSelect: (prompt: string) => void;
}

const starterTopics: HealthTopic[] = [
  {
    id: "nutrition",
    category: "Nutrition",
    title: "Healthy Eating",
    description: "Learn about balanced diets and nutrition basics",
    icon: "Apple",
    prompt: "What are the key principles of a healthy, balanced diet?",
  },
  {
    id: "mental-health",
    category: "Mental Health",
    title: "Mental Wellness",
    description: "Explore stress management and mindfulness",
    icon: "Brain",
    prompt: "What are some effective strategies for managing stress and anxiety?",
  },
  {
    id: "exercise",
    category: "Exercise",
    title: "Physical Activity",
    description: "Discover exercise recommendations and tips",
    icon: "Activity",
    prompt: "How much exercise should I get each week for optimal health?",
  },
  {
    id: "preventive",
    category: "Preventive Care",
    title: "Prevention",
    description: "Understand preventive health measures",
    icon: "Shield",
    prompt: "What preventive health screenings should I consider for my age group?",
  },
];

const iconMap = {
  Apple,
  Brain,
  Activity,
  Shield,
  Heart,
};

export function WelcomeScreen({ onTopicSelect }: WelcomeScreenProps) {
  return (
    <div className="flex items-center justify-center min-h-full p-6">
      <div className="max-w-2xl w-full space-y-8">
        <div className="text-center space-y-4">
          <img
            src={welcomeImage}
            alt="Health education illustration showing diverse people engaged in wellness activities"
            className="h-48 w-48 md:h-64 md:w-64 mx-auto object-contain"
            data-testid="img-welcome"
          />
          <h1 className="text-3xl font-bold text-foreground">
            Welcome to D Chatbot
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Your trusted AI assistant for community health education. Ask questions about nutrition, mental health, exercise, and preventive care.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {starterTopics.map((topic) => {
            const Icon = iconMap[topic.icon as keyof typeof iconMap] || Heart;
            return (
              <Card
                key={topic.id}
                className="p-4 hover-elevate active-elevate-2 cursor-pointer transition-all"
                onClick={() => onTopicSelect(topic.prompt)}
                data-testid={`card-topic-${topic.id}`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base font-medium text-foreground mb-1">
                      {topic.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {topic.description}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        <div className="text-center text-xs text-muted-foreground space-y-2">
          <p>
            <strong className="text-foreground">Important:</strong> This is an AI assistant for educational purposes only.
          </p>
          <p>
            Always consult qualified healthcare professionals for medical advice, diagnosis, or treatment.
          </p>
          <p className="text-destructive font-medium">
            In case of emergency, call your local emergency services immediately.
          </p>
        </div>
      </div>
    </div>
  );
}
