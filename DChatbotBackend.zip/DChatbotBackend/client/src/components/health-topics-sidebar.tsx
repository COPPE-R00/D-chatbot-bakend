import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Heart, Brain, Activity, Shield, Apple, Pill } from "lucide-react";
import { type HealthTopic } from "@shared/schema";

interface HealthTopicsSidebarProps {
  onTopicSelect: (prompt: string) => void;
}

const healthTopics: HealthTopic[] = [
  {
    id: "general",
    category: "General Health",
    title: "Health Basics",
    description: "General wellness information",
    icon: "Heart",
    prompt: "What are the fundamental pillars of good health?",
  },
  {
    id: "nutrition-1",
    category: "Nutrition",
    title: "Balanced Diet",
    description: "Nutritional guidance",
    icon: "Apple",
    prompt: "What constitutes a balanced and nutritious diet?",
  },
  {
    id: "nutrition-2",
    category: "Nutrition",
    title: "Hydration",
    description: "Water intake tips",
    icon: "Apple",
    prompt: "How much water should I drink daily and why is it important?",
  },
  {
    id: "mental-1",
    category: "Mental Health",
    title: "Stress Management",
    description: "Coping strategies",
    icon: "Brain",
    prompt: "What are evidence-based techniques for managing stress?",
  },
  {
    id: "mental-2",
    category: "Mental Health",
    title: "Sleep Health",
    description: "Better sleep habits",
    icon: "Brain",
    prompt: "How can I improve my sleep quality and establish healthy sleep habits?",
  },
  {
    id: "exercise-1",
    category: "Exercise",
    title: "Cardio Exercise",
    description: "Heart health",
    icon: "Activity",
    prompt: "What are the benefits of cardiovascular exercise and how often should I do it?",
  },
  {
    id: "exercise-2",
    category: "Exercise",
    title: "Strength Training",
    description: "Building muscle",
    icon: "Activity",
    prompt: "Why is strength training important and how should beginners start?",
  },
  {
    id: "preventive-1",
    category: "Preventive Care",
    title: "Health Screenings",
    description: "Early detection",
    icon: "Shield",
    prompt: "What routine health screenings should adults get regularly?",
  },
  {
    id: "preventive-2",
    category: "Preventive Care",
    title: "Vaccinations",
    description: "Immunization info",
    icon: "Shield",
    prompt: "What vaccinations are recommended for adults to stay protected?",
  },
  {
    id: "chronic",
    category: "Chronic Conditions",
    title: "Disease Management",
    description: "Living with conditions",
    icon: "Pill",
    prompt: "What are best practices for managing chronic health conditions?",
  },
];

const iconMap = {
  Heart,
  Brain,
  Activity,
  Shield,
  Apple,
  Pill,
};

export function HealthTopicsSidebar({ onTopicSelect }: HealthTopicsSidebarProps) {
  const categories = Array.from(new Set(healthTopics.map((t) => t.category)));

  return (
    <div className="w-64 border-r bg-sidebar h-full flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h2 className="text-lg font-medium text-sidebar-foreground">Health Topics</h2>
        <p className="text-xs text-muted-foreground mt-1">
          Explore common health questions
        </p>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {categories.map((category) => (
            <div key={category}>
              <h3 className="text-sm font-medium text-sidebar-foreground mb-4">
                {category}
              </h3>
              <div className="space-y-2">
                {healthTopics
                  .filter((topic) => topic.category === category)
                  .map((topic) => {
                    const Icon = iconMap[topic.icon as keyof typeof iconMap] || Heart;
                    return (
                      <Button
                        key={topic.id}
                        variant="ghost"
                        className="w-full justify-start h-auto p-3 text-left"
                        onClick={() => onTopicSelect(topic.prompt)}
                        data-testid={`button-topic-${topic.id}`}
                      >
                        <div className="flex items-start gap-3 w-full">
                          <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium">
                              {topic.title}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {topic.description}
                            </div>
                          </div>
                        </div>
                      </Button>
                    );
                  })}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
