import type { Express } from "express";
import { createServer, type Server } from "http";
import { chatRequestSchema } from "@shared/schema";
import { streamChatCompletion } from "./openai";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat streaming endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = chatRequestSchema.parse(req.body);
      
      // Prepare messages for OpenAI (convert from our schema to OpenAI format)
      const conversationHistory = validatedData.messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Add the new message
      conversationHistory.push({
        role: "user" as const,
        content: validatedData.message
      });

      // Stream AI response
      await streamChatCompletion(conversationHistory, res);
    } catch (error) {
      console.error("Chat error:", error);
      
      if (error instanceof ZodError) {
        // Validation error - 400 Bad Request
        res.status(400).json({ 
          error: "Invalid request data",
          details: error.errors 
        });
      } else if (error instanceof Error) {
        // Other errors - 500 Internal Server Error
        res.status(500).json({ 
          error: error.message || "Failed to process chat message" 
        });
      } else {
        res.status(500).json({ 
          error: "An unexpected error occurred" 
        });
      }
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
