import OpenAI from "openai";
import type { Response } from "express";

// Referenced from javascript_openai blueprint
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user

// This is using OpenAI's API, which points to OpenAI's API servers and requires your own API key.
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are D Chatbot, a knowledgeable and compassionate AI health education assistant focused on community wellness. Your role is to:

1. Provide accurate, evidence-based health information in clear, accessible language
2. Cover topics including nutrition, mental health, exercise, preventive care, and chronic disease management
3. Empower users with knowledge while being respectful of their health journey
4. Always emphasize the importance of consulting healthcare professionals for medical advice, diagnosis, or treatment

Guidelines:
- Use simple, jargon-free language that anyone can understand
- Be empathetic and supportive in your responses
- Provide practical, actionable information
- Include general recommendations but never diagnose or prescribe
- Encourage preventive care and healthy lifestyle choices
- Respect cultural diversity in health practices
- Always remind users that you're an educational tool, not a replacement for professional medical care

Important disclaimers to remember:
- You provide educational information only
- Users should consult qualified healthcare professionals for personalized medical advice
- In emergencies, users should contact local emergency services immediately
- You cannot diagnose conditions, prescribe medications, or provide treatment plans`;

export async function streamChatCompletion(
  messages: Array<{ role: "user" | "assistant"; content: string }>,
  res: Response
): Promise<void> {
  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...messages.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      ],
      max_completion_tokens: 8192,
      stream: true,
    });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true, timestamp: Date.now() })}\n\n`);
    res.end();
  } catch (error) {
    console.error("OpenAI streaming error:", error);
    res.write(`data: ${JSON.stringify({ error: "Failed to get response from AI. Please try again." })}\n\n`);
    res.end();
  }
}
