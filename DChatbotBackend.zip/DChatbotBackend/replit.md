# D Chatbot - Community Health Education Assistant

## Overview

D Chatbot is an AI-powered health education assistant designed to provide accessible, evidence-based health information to communities. The application features a conversational chat interface where users can ask health-related questions and receive educational responses covering topics like nutrition, mental health, exercise, preventive care, and chronic disease management. The system emphasizes that it provides educational information only and is not a replacement for professional medical care.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool

**UI Component System**: Shadcn/UI design system built on Radix UI primitives with Tailwind CSS for styling. The design follows a healthcare-focused UX approach, emphasizing trust, accessibility, and information clarity similar to telemedicine applications.

**Design Principles**:
- Mobile-first responsive design with breakpoints at 768px (tablet) and 1024px (desktop)
- Typography system using Inter font for readability in health content
- Spacing based on Tailwind utility units (2, 3, 4, 6, 8, 12)
- Chat-optimized layout with fixed header, scrollable message area, and fixed input area
- Maximum content width of 4xl for optimal reading

**State Management**: 
- React hooks for local component state
- TanStack Query (React Query) for server state management and API caching
- Custom hooks for mobile detection and toast notifications

**Routing**: Wouter for lightweight client-side routing (currently single-page application with chat interface)

**Key UI Components**:
- Chat message bubbles with distinct styling for user vs. assistant messages
- Real-time typing indicator during AI response streaming
- Welcome screen with health topic suggestions
- Collapsible sidebar for topic navigation
- Theme toggle supporting light/dark modes

### Backend Architecture

**Runtime**: Node.js with Express.js server

**API Design**: RESTful API with streaming support for real-time chat responses

**Key Endpoints**:
- `POST /api/chat`: Accepts conversation history and new message, streams AI response using Server-Sent Events (SSE)

**AI Integration**: OpenAI GPT-5 API for generating health education responses with custom system prompt that ensures appropriate medical disclaimers and educational focus

**Error Handling**: Centralized error handling with Zod validation for request schemas, returning appropriate HTTP status codes (400 for validation errors, 500 for server errors)

**Development Features**:
- Request/response logging middleware
- Vite integration for hot module replacement in development
- Custom error overlay for development debugging

### Data Storage Solutions

**Current Implementation**: In-memory storage using Map data structures (MemStorage class)

**Schema Design**: Drizzle ORM configured for PostgreSQL with migrations support, though currently using memory storage

**User Schema**: Basic user model with id, username fields defined but not actively used in current chat-only implementation

**Session Management**: Configured for PostgreSQL-backed sessions using connect-pg-simple (infrastructure ready but not actively utilized)

**Database Configuration**: 
- Drizzle config points to PostgreSQL dialect
- Schema defined in shared/schema.ts
- Migration output directory: ./migrations
- Database connection via DATABASE_URL environment variable

### Authentication and Authorization

**Current State**: Authentication infrastructure is present but not actively enforced. The application currently operates as an open chat interface without user authentication requirements.

**Future Capability**: User schema and session store infrastructure are in place for implementing authentication when needed.

### External Dependencies

**AI Service**: 
- OpenAI API (GPT-5 model) for chat completions
- Streaming response support for real-time user experience
- Custom system prompt enforcing health education guidelines and medical disclaimers

**Database Service**: 
- Neon PostgreSQL configured via @neondatabase/serverless
- Drizzle ORM for type-safe database queries
- connect-pg-simple for PostgreSQL-backed session storage (ready for use)

**UI Component Libraries**:
- Radix UI primitives for accessible, unstyled component foundations
- Tailwind CSS for utility-first styling
- shadcn/ui as the cohesive design system
- Lucide React for consistent iconography

**Build and Development Tools**:
- Vite for fast development and optimized production builds
- TypeScript for type safety across frontend and backend
- ESBuild for server-side bundling
- PostCSS with Tailwind and Autoprefixer

**Validation**: Zod for runtime schema validation on both client and server

**Date Handling**: date-fns for timestamp formatting and relative time display

**Deployment Platform**: Configured for Replit with specialized Vite plugins for development banners, cartographer, and runtime error modals